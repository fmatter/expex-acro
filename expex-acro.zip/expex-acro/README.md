# expex-acro
[expex](https://ctan.org/pkg/expex) with exrefs and glossing abbreviations.

e-mail: florianmatter@gmail.com

Released under the LaTeX Project Public License v1.3c or later, see [https://www.latex-project.org/lppl.txt](https://www.latex-project.org/lppl.txt).