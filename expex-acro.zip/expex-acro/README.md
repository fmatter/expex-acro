# expex-acro --- expex with exrefs and glossing abbreviations

e-mail: mailto:florianmatter@gmail.com
Released under the LaTeX Project Public License v1.3c or later, see [https://www.latex-project.org/lppl.txt](https://www.latex-project.org/lppl.txt).