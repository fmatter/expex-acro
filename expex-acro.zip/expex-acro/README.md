# expex-acro
This package is a small wrapper for the excellent [expex](https://ctan.org/pkg/expex), adding ways to define, use, and summarize glossing abbreviations. It also provides commands to refer to examples, as well as some inline formatting commands commonly used in linguistics.

e-mail: florianmatter@gmail.com

Released under the LaTeX Project Public License v1.3c or later, see [https://www.latex-project.org/lppl.txt](https://www.latex-project.org/lppl.txt).